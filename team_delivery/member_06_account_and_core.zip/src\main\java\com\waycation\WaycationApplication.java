package com.waycation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main entry point for the waYcation 2.0 platform.
 * Bootstraps Spring MVC controllers, Spring Data JPA repositories, PostgreSQL transaction
 * management, and Thymeleaf server-side HTML5 rendering.
 */
@SpringBootApplication
@EnableTransactionManagement
public class WaycationApplication {

    public static void main(String[] args) {
        SpringApplication.run(WaycationApplication.class, args);
    }
}
